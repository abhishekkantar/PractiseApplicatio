var input = document.getElementById("txtToDoTask");
input.addEventListener("keyup", function (event) {
    if (event.keyCode === 13) {
        event.preventDefault();
        input.value ? addTask(input.value) : alert("Enter some value in to-do task field.");
        input.value = "";
    }
});
function addTask(value) {
    const element = document.createElement('ul');

    element.innerHTML = `<br /><li>` + value + `
                       <span class="close" onclick="removeTask(this)">X</span></li>`;

    document.getElementById('divAddedTask').appendChild(element);
}
function removeTask(input) {
    document.getElementById('divAddedTask').removeChild(input.parentNode.parentNode);
}